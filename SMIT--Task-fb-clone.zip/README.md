# SMIT--Task-fb-clone
this repo contains SMIT task which was to clone facebook signup page
